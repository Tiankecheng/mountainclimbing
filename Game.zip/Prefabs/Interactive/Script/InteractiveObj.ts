﻿
export namespace InteractiveEvent {
	/**背包开关 */
	export let IE_OpenBag: string = "IE_OpenBag";
	/**按钮执行交互逻辑 */
	export let IE_Interact: string = "IE_Interact";
	/**开关交互按钮 */
	export let IE_OpenInteractUI: string = "IE_OpenInteractUI";
}
@Core.Class
export default class InteractiveObj extends Core.Script {

	// !--stance only
	@Core.Property({ displayName: "预加载资源" })
	preloadAssets = "4175";
	@Core.Property({ displayName: "离开坐标" })
	exitLoc: Type.Vector = Type.Vector.zero;

	// MAKER: 声明触发器、交互物、角色变量
	private _trigger: Gameplay.Trigger | undefined = undefined;
	private _interactor: Gameplay.Interactor | undefined = undefined;
	private _gameChar: Gameplay.Character | undefined;
	private isFull: boolean = false;

	protected onStart(): void {
		let id = setInterval(() => {
			this._trigger = this.gameObject.getChildByName("Box_Trigger") as Gameplay.Trigger
			this._interactor = this.gameObject as Gameplay.Interactor;
			if (this._trigger && this._interactor) {
				clearInterval(id);
				this.init();
			}
		}, 30);
	}

	private async init() {
		// MAKER: 角色进入触发器
		this._trigger.onEnter.add((other) => {
			if (!(other instanceof Gameplay.Character)) {
				return;
			}
			if (this.isFull) {
				return;
			}
			// MAKER: 获取进入触发器角色
			this._gameChar = <Gameplay.Character>other;
			this.isFull = true;
			if (!Gameplay.isClient()) {
				return;
			}
			if (this._gameChar != Gameplay.getCurrentPlayer().character) {
				return;
			}
			// MAKER: 打开交互UI
			Events.dispatchLocal(InteractiveEvent.IE_OpenInteractUI, true)
		});
		// MAKER: 角色退出触发器
		this._trigger.onLeave.add((other) => {
			if (other != this._gameChar) {
				return;
			}

			if (Gameplay.isClient()) {
				if (this._gameChar == Gameplay.getCurrentPlayer().character) {
					// MAKER: 关闭交互UI
					Events.dispatchLocal(InteractiveEvent.IE_OpenInteractUI, false)
				}
			}

			// MAKER: 置空角色变量
			this._gameChar = undefined;
			this.isFull = false;
		});

		if (!Gameplay.isClient()) {
			return;
		}

		// MAKER: 事件监听，挂载交互物
		Events.addLocalListener(InteractiveEvent.IE_Interact, (flag) => {
			if (!this._interactor || !this._gameChar) {
				return;
			}
			// MAKER: 非交互状态
			if (!flag) {
				// MAKER: 激活交互物，将角色以设定动画姿态挂载到交互对象
				this._interactor.enterInteractiveState(this._gameChar)
				Events.dispatchLocal(InteractiveEvent.IE_OpenBag, false)
			}
		});

		// MAKER: 事件监听，退出交互状态
		Events.addLocalListener(InteractiveEvent.IE_Interact, (flag) => {
			if (!this._interactor) {
				return;
			}
			// MAKER: 已交互状态
			if (flag) {
				// MAKER: 角色退出交互物
				this._interactor.exitInteractiveState(this._interactor.worldLocation.add(this.exitLoc));

				Events.dispatchLocal(InteractiveEvent.IE_OpenBag, true)
			}
		});
	}
}