/**
 * @Author       : 田可成
 * @Date         : 2022-10-12 09:17:17
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-10-31 10:47:59
 * @FilePath     : \ilovethemountains\Prefabs\Bonfire\Script\SavePoint.ts
 * @Description  : 
 */
export namespace SavePointEvent {
    /**进入存档点 */
    export let SP_EnterSavePoint: string = "SP_EnterSavePoint";
    /**进入触发器 */
    export let SP_OnEnterTrriger: string = "SP_OnEnterTrriger";
    /**离开触发器 */
    export let SP_OnLeaveTrriger: string = "SP_OnLeaveTrriger";
}
@Core.Class
export default class SavePoint extends Core.Script {
    @Core.Property({ displayName: "复活点" })
    rebornPoint = Type.Vector.zero
    @Core.Property({ displayName: "体力回复值" })
    staminaRevert = 5
    @Core.Property({ displayName: "是否存档" })
    isSavePoint = true
    @Core.Property({ displayName: "存档点ID" })
    savePointID = 1;
    @Core.Property({ displayName: "增加金币" })
    addGold = 0;
    private _trigger: Gameplay.Trigger

    protected onStart(): void {
        if (Gameplay.isClient()) {
            let id = setInterval(() => {
                this._trigger = this.gameObject.getChildByName("BP_BoxTrigger") as Gameplay.Trigger
                if (this._trigger) {
                    clearInterval(id);
                    this.createEvent();
                }
            }, 30);
        }
    }

    private createEvent() {
        this._trigger.onEnter.add((other: Core.GameObject) => {
            if (other instanceof Gameplay.Character && Gameplay.getCurrentPlayer().character.guid == other.guid) {
                Events.dispatchLocal(SavePointEvent.SP_OnEnterTrriger, [this.staminaRevert])
                if (this.isSavePoint) {
                    Events.dispatchLocal(SavePointEvent.SP_EnterSavePoint, [this.savePointID, this.addGold, this.rebornPoint])
                }
            }
        })
        this._trigger.onLeave.add((other: Core.GameObject) => {
            if (other instanceof Gameplay.Character && Gameplay.getCurrentPlayer().character.guid == other.guid) {
                Events.dispatchLocal(SavePointEvent.SP_OnLeaveTrriger, [this.savePointID, this.addGold, this.rebornPoint])
            }
        })
    }
}
