﻿/**
 * @Author       : 田可成
 * @Date         : 2022-09-20 19:16:29
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-12-26 13:21:36
 * @FilePath     : \ilovethemountains\Prefabs\PlayerScore\Script\PlayerScore.ts
 * @Description  : 
 */
import { ClientEvents } from "../../../JavaScripts/const/LocalEvents";
import ScoreMgr, { IPlayerScore } from "./ScoreMgr";

@Core.Class
export default class PlayerScore extends Core.Script implements IPlayerScore {
	enble_S = false

	@Core.Property({ replicated: true, onChanged: "onRepProp" })
	pid = 0;

	@Core.Property({ replicated: true, onChanged: "onRepProp" })
	nickName = "";

	@Core.Property({ replicated: true, onChanged: "onRepProp" })
	savePoint = 0;

	@Core.Property({ replicated: true, onChanged: "onRepProp" })
	topCount = 0;

	@Core.Property({ replicated: true, onChanged: "onRepProp" })
	height = 0;

	init(pid: number, nickName: string, topCount: number) {
		this.enble_S = true;
		this.savePoint = 1;
		this.height = 1000;
		this.pid = pid
		this.nickName = nickName;
		this.topCount = topCount;
	}

	protected onStart(): void {
		if (Gameplay.isClient())
			ScoreMgr.instance.onPlayerRegiser(this)
	}

	onRepProp() {
		if (Gameplay.isClient()) {
			Events.dispatchLocal(ClientEvents.Ev_RefreshRank_Client);
		}
	}
}
