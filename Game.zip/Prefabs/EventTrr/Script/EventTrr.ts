﻿/**
 * @Author       : 田可成
 * @Date         : 2022-09-21 11:28:09
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-11-13 17:17:32
 * @FilePath     : \ilovethemountains\Prefabs\EventTrr\Script\EventTrr.ts
 * @Description  : 
 */
export namespace TrrEvent {
	/**进入触发器 */
	export let Trr_OnEnterTrriger: string = "Trr_OnEnterTrriger";
}
import { ClientEvents } from "../../../JavaScripts/const/LocalEvents";
@Core.Class
export default class EventTrr extends Core.Script {

	@Core.Property({ displayName: "触发事件ID" })
	eventID: number = 1
	@Core.Property({ displayName: "刷新事件类型" })
	eventType: string = "1"
	@Core.Property({ displayName: "刷新事件数量" })
	eventCount: number = 1
	@Core.Property({ displayName: "交互后隐藏的场景物guid" })
	destroyGuid: string = "";
	@Core.Property({ displayName: "是否是用于引导的事件" })
	private _isGuide: boolean = false
	private _isEnter: boolean = false
	private _trigger: Gameplay.Trigger

	protected onStart(): void {
		if (Gameplay.isClient()) {
			Events.addLocalListener(ClientEvents.EV_ResetGame, () => { this._isEnter = false })
			Events.addLocalListener(ClientEvents.EV_EnterGuide, () => { if (this._isGuide) this._isEnter = true })
			let id = setInterval(() => {
				this._trigger = this.gameObject.getChildByName("BP_BoxTrigger") as Gameplay.Trigger
				if (this._trigger) {
					clearInterval(id);
					this.createEvent();
				}
			}, 30);
		}
	}

	private createEvent() {
		this._trigger.onEnter.add((other: Core.GameObject) => {
			if (other instanceof Gameplay.Character && Gameplay.getCurrentPlayer().character.guid == other.guid) {
				if (!this._isEnter) {
					this._isEnter = true
					Events.dispatchLocal(TrrEvent.Trr_OnEnterTrriger, [this.eventID, this.eventType, this.eventCount, this.destroyGuid])
				}
			}
		})
	}
}
