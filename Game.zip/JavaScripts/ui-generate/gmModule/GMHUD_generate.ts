﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/gmModule/GMHUD.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/gmModule/GMHUD.ui')
 export default class GMHUD_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('MWCanvas_2147482460/oKbutton')
    public oKbutton: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/dropList')
    public dropList: UI.ScrollBox=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/argText')
    public argText: UI.InputBox=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/cmdButton')
    public cmdButton: UI.StaleButton=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.oKbutton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "oKbutton");
		})
		this.initLanguage(this.oKbutton);
		this.oKbutton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.cmdButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "cmdButton");
		})
		this.initLanguage(this.cmdButton);
		this.cmdButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		//文本多语言
		

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 