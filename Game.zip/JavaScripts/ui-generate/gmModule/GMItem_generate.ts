﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/gmModule/GMItem.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/gmModule/GMItem.ui')
 export default class GMItem_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('MWCanvas_2147482460/button')
    public button: UI.StaleButton=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.button.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "button");
		})
		this.initLanguage(this.button);
		this.button.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		//文本多语言
		

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 