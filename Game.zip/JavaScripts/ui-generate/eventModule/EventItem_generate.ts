﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/eventModule/EventItem.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/eventModule/EventItem.ui')
 export default class EventItem_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('MWCanvas_2147482460/mBackImg')
    public mBackImg: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mDesc')
    public mDesc: UI.TextBlock=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mBtn')
    public mBtn: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mEventName')
    public mEventName: UI.TextBlock=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.mBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mBtn");
		})
		this.initLanguage(this.mBtn);
		this.mBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mDesc)
		
	
		this.initLanguage(this.mEventName)
		
	
		//文本多语言
		

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 