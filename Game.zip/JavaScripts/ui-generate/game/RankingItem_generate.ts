﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/game/RankingItem.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/game/RankingItem.ui')
 export default class RankingItem_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('Canvas/rankCanvas/rankTxt')
    public rankTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/rankCanvas/nameTxt')
    public nameTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/rankCanvas/scoreTxt')
    public scoreTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/rankCanvas/numberTxt')
    public numberTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/rankCanvas/heightTxt')
    public heightTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/rankCanvas')
    public rankCanvas: UI.Canvas=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.rankTxt)
		
	
		this.initLanguage(this.nameTxt)
		
	
		this.initLanguage(this.scoreTxt)
		
	
		this.initLanguage(this.numberTxt)
		
	
		this.initLanguage(this.heightTxt)
		
	
		//文本多语言
		

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 