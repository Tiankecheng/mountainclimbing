﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/game/SkyBoxGM.ui
 * TIME: 2022.12.27-14.06.27
 */

 

 @UI.UICallOnly('UI/game/SkyBoxGM.ui')
 export default class SkyBoxGM_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('MWCanvas_2147482460/mBtn')
    public mBtn: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mInput1')
    public mInput1: UI.InputBox=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mInput2')
    public mInput2: UI.InputBox=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mInput3')
    public mInput3: UI.InputBox=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mInput4')
    public mInput4: UI.InputBox=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mInput5')
    public mInput5: UI.InputBox=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mInput6')
    public mInput6: UI.InputBox=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.mBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mBtn");
		})
		this.initLanguage(this.mBtn);
		this.mBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWTextBlock_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWTextBlock_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWTextBlock_1_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWTextBlock_1_1_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWTextBlock_1_1_1_1_1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWTextBlock_1_1_1_1_1_1") as any);
		
	

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 