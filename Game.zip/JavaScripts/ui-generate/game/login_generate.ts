﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/game/login.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/game/login.ui')
 export default class login_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('MWCanvas_2147482460/leftBtn')
    public leftBtn: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/rightBtn')
    public rightBtn: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mGuide1')
    public mGuide1: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/confirmBtn')
    public confirmBtn: UI.StaleButton=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.leftBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "leftBtn");
		})
		this.initLanguage(this.leftBtn);
		this.leftBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.rightBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "rightBtn");
		})
		this.initLanguage(this.rightBtn);
		this.rightBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.confirmBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "confirmBtn");
		})
		this.initLanguage(this.confirmBtn);
		this.confirmBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		//文本多语言
		

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 