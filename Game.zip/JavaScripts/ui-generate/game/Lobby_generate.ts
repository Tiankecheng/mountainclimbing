﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/game/Lobby.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/game/Lobby.ui')
 export default class Lobby_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('Canvas/Gold/mGoldCnt')
    public mGoldCnt: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/Gold/mGoldImg')
    public mGoldImg: UI.Image=undefined;
    @UI.UIMarkPath('Canvas/mSetUp')
    public mSetUp: UI.StaleButton=undefined;
    @UI.UIMarkPath('Canvas/mEmergency')
    public mEmergency: UI.StaleButton=undefined;
    @UI.UIMarkPath('Canvas/mSZTxt')
    public mSZTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mJumpBtn')
    public mJumpBtn: UI.StaleButton=undefined;
    @UI.UIMarkPath('Canvas/mTYTxt')
    public mTYTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mCSTXT')
    public mCSTXT: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mCSTXT_1')
    public mCSTXT_1: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/shopBtn')
    public shopBtn: UI.StaleButton=undefined;
    @UI.UIMarkPath('Canvas/mProperty/hpProgressBar')
    public hpProgressBar: UI.ProgressBar=undefined;
    @UI.UIMarkPath('Canvas/mProperty/hpTxt')
    public hpTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mProperty/strProgressBar')
    public strProgressBar: UI.ProgressBar=undefined;
    @UI.UIMarkPath('Canvas/mProperty/strTxt')
    public strTxt: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mProperty/mHpGuideImg')
    public mHpGuideImg: UI.Image=undefined;
    @UI.UIMarkPath('Canvas/mProperty/mStaminaGuideImg')
    public mStaminaGuideImg: UI.Image=undefined;
    @UI.UIMarkPath('Canvas/mProperty/mGuideImg')
    public mGuideImg: UI.Image=undefined;
    @UI.UIMarkPath('Canvas/mProperty/mLife')
    public mLife: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mProperty')
    public mProperty: UI.Canvas=undefined;
    @UI.UIMarkPath('Canvas/mRankPanel/RankFrame/mRankText')
    public mRankText: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mRankPanel/RankFrame/mNameText')
    public mNameText: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mRankPanel/RankFrame/mScoreText')
    public mScoreText: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mRankPanel/RankFrame/mNumberText')
    public mNumberText: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mRankPanel/RankFrame/mHeightText')
    public mHeightText: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mRankPanel/RankFrame/RankList/rankCanvas')
    public rankCanvas: UI.Canvas=undefined;
    @UI.UIMarkPath('Canvas/mRankPanel')
    public mRankPanel: UI.Canvas=undefined;
    @UI.UIMarkPath('Canvas/mHurt')
    public mHurt: UI.Image=undefined;
    @UI.UIMarkPath('Canvas/mAdv')
    public mAdv: UI.Button=undefined;
    @UI.UIMarkPath('Canvas/mAdCountDown')
    public mAdCountDown: UI.TextBlock=undefined;
    @UI.UIMarkPath('Canvas/mAdTips')
    public mAdTips: UI.TextBlock=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.mSetUp.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mSetUp");
		})
		this.initLanguage(this.mSetUp);
		this.mSetUp.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mEmergency.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mEmergency");
		})
		this.initLanguage(this.mEmergency);
		this.mEmergency.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mJumpBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mJumpBtn");
		})
		this.initLanguage(this.mJumpBtn);
		this.mJumpBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.shopBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "shopBtn");
		})
		this.initLanguage(this.shopBtn);
		this.shopBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		
		this.mAdv.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mAdv");
		})
		this.mAdv.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	

		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mGoldCnt)
		
	
		this.initLanguage(this.mSZTxt)
		
	
		this.initLanguage(this.mTYTxt)
		
	
		this.initLanguage(this.mCSTXT)
		
	
		this.initLanguage(this.mCSTXT_1)
		
	
		this.initLanguage(this.hpTxt)
		
	
		this.initLanguage(this.strTxt)
		
	
		this.initLanguage(this.mLife)
		
	
		this.initLanguage(this.mRankText)
		
	
		this.initLanguage(this.mNameText)
		
	
		this.initLanguage(this.mScoreText)
		
	
		this.initLanguage(this.mNumberText)
		
	
		this.initLanguage(this.mHeightText)
		
	
		this.initLanguage(this.mAdCountDown)
		
	
		this.initLanguage(this.mAdTips)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("Canvas/mAdv/TextBlock_2") as any);
		
	

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 