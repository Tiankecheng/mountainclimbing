﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/commonUI/Tips.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/commonUI/Tips.ui')
 export default class Tips_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('Canvas/mCell1')
    public mCell1: UI.Canvas=undefined;
    @UI.UIMarkPath('Canvas/mCell2')
    public mCell2: UI.Canvas=undefined;
    @UI.UIMarkPath('Canvas/mCell3')
    public mCell3: UI.Canvas=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("Canvas/mCell1/Content_txt") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("Canvas/mCell2/Content_txt") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("Canvas/mCell3/Content_txt") as any);
		
	

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 