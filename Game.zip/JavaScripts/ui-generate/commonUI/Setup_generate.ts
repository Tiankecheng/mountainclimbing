﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/commonUI/Setup.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/commonUI/Setup.ui')
 export default class Setup_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('RootCanvas/Main/mAudioGroup/mAudioTitle')
    public mAudioTitle: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/Main/mAudioGroup/mAudioButton')
    public mAudioButton: UI.StaleButton=undefined;
    @UI.UIMarkPath('RootCanvas/Main/mAudioGroup/mAudioMark')
    public mAudioMark: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/Main/mAudioGroup')
    public mAudioGroup: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/Main/mMWTextBlock_1')
    public mMWTextBlock_1: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/Main/mcontiue')
    public mcontiue: UI.StaleButton=undefined;
    @UI.UIMarkPath('RootCanvas/Main/mcloseButton')
    public mcloseButton: UI.StaleButton=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.mAudioButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mAudioButton");
		})
		this.initLanguage(this.mAudioButton);
		this.mAudioButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mcontiue.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mcontiue");
		})
		this.initLanguage(this.mcontiue);
		this.mcontiue.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mcloseButton.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mcloseButton");
		})
		this.initLanguage(this.mcloseButton);
		this.mcloseButton.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mAudioTitle)
		
	
		this.initLanguage(this.mMWTextBlock_1)
		
	
		//文本多语言
		

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 