﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/commercialize/AdvUI.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/commercialize/AdvUI.ui')
 export default class AdvUI_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('RootCanvas/mYes')
    public mYes: UI.StaleButton=undefined;
    @UI.UIMarkPath('RootCanvas/mNo')
    public mNo: UI.StaleButton=undefined;
    @UI.UIMarkPath('RootCanvas/mboots/mImage')
    public mImage: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/mboots/mBootsText')
    public mBootsText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/mboots')
    public mboots: UI.Canvas=undefined;
    @UI.UIMarkPath('RootCanvas/mMedical/mImage_1')
    public mImage_1: UI.Image=undefined;
    @UI.UIMarkPath('RootCanvas/mMedical/mMedicalText')
    public mMedicalText: UI.TextBlock=undefined;
    @UI.UIMarkPath('RootCanvas/mMedical')
    public mMedical: UI.Canvas=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.mYes.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mYes");
		})
		this.initLanguage(this.mYes);
		this.mYes.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mNo.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mNo");
		})
		this.initLanguage(this.mNo);
		this.mNo.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mBootsText)
		
	
		this.initLanguage(this.mMedicalText)
		
	
		//文本多语言
		

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 