﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/guideModule/GuideModuleUI.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/guideModule/GuideModuleUI.ui')
 export default class GuideModuleUI_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('MWCanvas_2147482460/mLeftMask')
    public mLeftMask: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mTopMask')
    public mTopMask: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mButtomMask')
    public mButtomMask: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mRightMask')
    public mRightMask: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mBtn')
    public mBtn: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/image')
    public image: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mBtnHand')
    public mBtnHand: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mTextHand')
    public mTextHand: UI.TextBlock=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.mLeftMask.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mLeftMask");
		})
		this.initLanguage(this.mLeftMask);
		this.mLeftMask.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mTopMask.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mTopMask");
		})
		this.initLanguage(this.mTopMask);
		this.mTopMask.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mButtomMask.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mButtomMask");
		})
		this.initLanguage(this.mButtomMask);
		this.mButtomMask.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mRightMask.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mRightMask");
		})
		this.initLanguage(this.mRightMask);
		this.mRightMask.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mBtn");
		})
		this.initLanguage(this.mBtn);
		this.mBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mTextHand)
		
	
		//文本多语言
		

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 