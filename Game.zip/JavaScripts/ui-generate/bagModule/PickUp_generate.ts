﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/bagModule/PickUp.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/bagModule/PickUp.ui')
 export default class PickUp_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_1/mPickup')
    public mPickup: UI.StaleButton=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.mPickup.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mPickup");
		})
		this.initLanguage(this.mPickup);
		this.mPickup.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		//文本多语言
		

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 