﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/bagModule/BagMain.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/bagModule/BagMain.ui')
 export default class BagMain_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('MWCanvas_2147482460/mItemDetail/btn')
    public btn: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mItemDetail/MWCanvas_1/mItemImage')
    public mItemImage: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mItemDetail/MWCanvas_1/mName')
    public mName: UI.TextBlock=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mItemDetail/MWCanvas_1/mDesc')
    public mDesc: UI.TextBlock=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mItemDetail/MWCanvas_1/mUseBtn')
    public mUseBtn: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mItemDetail/MWCanvas_1/mDiscardBtn')
    public mDiscardBtn: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mItemDetail')
    public mItemDetail: UI.Canvas=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/btn1')
    public btn1: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mBackImg')
    public mBackImg: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mGuideImg1')
    public mGuideImg1: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mScrollBox/mContent')
    public mContent: UI.Canvas=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/mScrollBox')
    public mScrollBox: UI.ScrollBox=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.btn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btn");
		})
		this.initLanguage(this.btn);
		this.btn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mUseBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mUseBtn");
		})
		this.initLanguage(this.mUseBtn);
		this.mUseBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mDiscardBtn.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mDiscardBtn");
		})
		this.initLanguage(this.mDiscardBtn);
		this.mDiscardBtn.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.btn1.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btn1");
		})
		this.initLanguage(this.btn1);
		this.btn1.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mName)
		
	
		this.initLanguage(this.mDesc)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWTextBlock_1") as any);
		
	

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 