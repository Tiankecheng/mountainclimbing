﻿
/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 维纟丶酱
 * UI: UI/facad/FacadMain.ui
 * TIME: 2022.12.27-14.06.26
 */

 

 @UI.UICallOnly('UI/facad/FacadMain.ui')
 export default class FacadMain_Generate extends UI.UIBehaviour {
	 @UI.UIMarkPath('MWCanvas_2147482460/intervalLine_down')
    public intervalLine_down: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/basepicture')
    public basepicture: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/intervalLine_up')
    public intervalLine_up: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/btn1')
    public btn1: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/btn2')
    public btn2: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/btn3')
    public btn3: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/btn4')
    public btn4: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/btn5')
    public btn5: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/btn6')
    public btn6: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/btn7')
    public btn7: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/mScrollBox/mContent')
    public mContent: UI.Canvas=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/mScrollBox')
    public mScrollBox: UI.ScrollBox=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2147482460/mBtnSave')
    public mBtnSave: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_4/MWCanvas_2147482460/mBtnClose')
    public mBtnClose: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_5/mTouch')
    public mTouch: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_5/MWCanvas_3/btnLeft')
    public btnLeft: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_5/MWCanvas_3/btnRight')
    public btnRight: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_5/MWCanvas_3/btnReset')
    public btnReset: UI.StaleButton=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_5/MWCanvas_3/mPos')
    public mPos: UI.Image=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/MWCanvas_5/mLog')
    public mLog: UI.TextBlock=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/Gold/mGoldCnt')
    public mGoldCnt: UI.TextBlock=undefined;
    @UI.UIMarkPath('MWCanvas_2147482460/Gold/mGoldImg')
    public mGoldImg: UI.Image=undefined;
    

 
	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = Extension.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		this.btn1.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btn1");
		})
		this.initLanguage(this.btn1);
		this.btn1.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.btn2.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btn2");
		})
		this.initLanguage(this.btn2);
		this.btn2.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.btn3.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btn3");
		})
		this.initLanguage(this.btn3);
		this.btn3.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.btn4.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btn4");
		})
		this.initLanguage(this.btn4);
		this.btn4.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.btn5.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btn5");
		})
		this.initLanguage(this.btn5);
		this.btn5.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.btn6.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btn6");
		})
		this.initLanguage(this.btn6);
		this.btn6.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.btn7.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btn7");
		})
		this.initLanguage(this.btn7);
		this.btn7.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mBtnSave.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mBtnSave");
		})
		this.initLanguage(this.mBtnSave);
		this.mBtnSave.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.mBtnClose.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "mBtnClose");
		})
		this.initLanguage(this.mBtnClose);
		this.mBtnClose.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.btnLeft.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btnLeft");
		})
		this.initLanguage(this.btnLeft);
		this.btnLeft.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.btnRight.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btnRight");
		})
		this.initLanguage(this.btnRight);
		this.btnRight.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		this.btnReset.onClicked.add(()=>{
			Events.dispatchLocal("PlayButtonClick", "btnReset");
		})
		this.initLanguage(this.btnReset);
		this.btnReset.touchMethod = (UI.ButtonTouchMethod.PreciseTap);
		
	
		//按钮添加点击
		

		//按钮多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWButton_1") as any);
		
	
		//文本多语言
		
		this.initLanguage(this.mLog)
		
	
		this.initLanguage(this.mGoldCnt)
		
	
		//文本多语言
		
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/TextBtn1") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/TextBtn2") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/TextBtn3") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/TextBtn4") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/TextBtn5") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/TextBtn6") as any);
		
	
		this.initLanguage(this.uiWidgetBase.findChildByPath("MWCanvas_2147482460/MWCanvas_4/MWCanvas_2/MWCanvas_1/TextBtn7") as any);
		
	

	}
	private initLanguage(ui: UI.StaleButton | UI.TextBlock) {
        let call = UI.UIBehaviour.getBehaviour("lan");
        if (call && ui) {
            call(ui);
        }
    }
 }
 