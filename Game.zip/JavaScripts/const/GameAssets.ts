/**
 * @Author       : 田可成
 * @Date         : 2022-07-20 09:58:20
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-12-27 10:59:25
 * @FilePath     : \ilovethemountains\JavaScripts\const\GameAssets.ts
 * @Description  : 
 */
export class GameAssets {
    /**
    * 引导线Guid
    */
    public static GuideArrowGuid: string = "7697";

    /**
     * 引导线材质Guid
     */
    public static GuideArrowMartialGuid: string = "13587";

    /**
     * 目的地特效Guid
     */
    public static GuideWorldTargetEffectGuid: string = "21638";

    /**天空盒 */
    public static SkyBox = "E490A8074A4B41BD225E6E9A7870D9F6"

    /**立方体触发器 */
    static readonly TRIGGER_BOX: string = "113";

    /**世界UI */
    static readonly WORLD_UI: string = "16037"
}
