﻿/**
 * @Author       : 田可成
 * @Date         : 2022-08-19 18:08:07
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-10-30 18:13:20
 * @FilePath     : \ilovethemountains\JavaScripts\ui\TouchUI.ts
 * @Description  : 
 */

import { TouchScript } from "module_facad";

export default class TouchUI extends TouchScript {


}