/**
 * @Author       : 田可成
 * @Date         : 2022-12-26 11:31:43
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-12-26 13:59:47
 * @FilePath     : \ilovethemountains\JavaScripts\ui\P_SetUpUI.ts
 * @Description  : 
 */
import { ModuleManager } from "odin";
import { GlobalVas } from "../const/GlobalDefine";
import { BagModule_Clinet } from "../modules/commonModules/bagModule/BagModule_Clinet";
import P_LobbyUI from "../modules/gameModule/P_LobbyUI";
import Setup_Generate from "../ui-generate/commonUI/Setup_generate";
import { Util } from "../util/Util";

export class P_SetUp_UI extends Setup_Generate {
    private volumScale: number = 0
    onStart() {
        this.mcloseButton.onClicked.add(() => {
            Util.playSound(16)
            this.visible = false;
            GlobalVas.g_GameIsPause = false
            Extension.UIManager.instance.show(P_LobbyUI)
            ModuleManager.instance.getModule(BagModule_Clinet).openBag();
        })
        this.volumScale = Extension.SoundManager.getInstance().volumeScale
        this.mAudioButton.onClicked.add(() => {
            Util.playSound(16)
            if (Extension.SoundManager.getInstance().volumeScale > 0) {
                Extension.SoundManager.getInstance().volumeScale = 0
                this.mAudioMark.visibility = UI.SlateVisibility.Collapsed
            } else {
                Extension.SoundManager.getInstance().volumeScale = this.volumScale
                this.mAudioMark.visibility = UI.SlateVisibility.HitTestInvisible
            }
        })

        this.mcontiue.onClicked.add(() => {
            Util.playSound(16)
            this.visible = false;
            Extension.UIManager.instance.show(P_LobbyUI)
            ModuleManager.instance.getModule(BagModule_Clinet).openBag();
        })
    }

    onShow(...params: any[]): void {
        GlobalVas.g_GameIsPause = true
    }

}