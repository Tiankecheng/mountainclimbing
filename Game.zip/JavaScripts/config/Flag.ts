import { ConfigBase, IElementBase } from "./ConfigBase";
const EXCELDATA:Array<Array<any>> = [["ID","Name","PosOffset","Scale","Rotate","Guid"],["","","","","",""],[1,"红色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"0D0AB59B497DEEEC5B929D84AF039761"],[2,"蓝色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"D71B6F7044ADF3DFAC7D1BA3187D9E24"],[3,"黄色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"6D94EF57497D2F1375CA70B16AE83ABE"],[4,"波纹",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"90A763EF4B7FFDB3BE8CC4AE6A46DB9B"],[5,"绿色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"12DA84DD48827073FC02D4B13B6E6CFF"],[6,"黑色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"811C5E604FE27864747AD09F4C48A23D"],[7,"橙色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"7C3536F943925E57953B5ABC5DAD6AE3"],[8,"粉红色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"BFB7788845988622B859668FBC8381C7"],[9,"粉红色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"5917B0004BB8135D2CC8DC819D67CBED"],[10,"粉红色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"F2188DA34F8B7A61958EB29C29BE2B46"],[11,"粉红色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"035325794985A5530D65F6A79FCBE8BB"],[12,"粉红色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"CB5978A2400C8E86F6FA0AA8E051AF19"],[13,"粉红色",new Type.Vector(0,0,-120),new Type.Vector(0.5,0.5,0.5),new Type.Vector(0,0,-30),"F518413F4290BE264D1656952B71F1DB"]];
export interface IFlagElement extends IElementBase{
 	/**q_id*/
	ID:number
	/**旗帜名字*/
	Name:string
	/**相对位置*/
	PosOffset:Type.Vector
	/**相对缩放*/
	Scale:Type.Vector
	/**相对旋转*/
	Rotate:Type.Vector
	/**场景中旗帜物体guid*/
	Guid:string
 } 
export class FlagConfig extends ConfigBase<IFlagElement>{
	constructor(){
		super(EXCELDATA);
	}

}