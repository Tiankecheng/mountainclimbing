/**
 * @Author       : 田可成
 * @Date         : 2022-08-31 18:14:43
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-10-30 17:31:51
 * @FilePath     : \ilovethemountains\JavaScripts\util\WorldUI.ts
 * @Description  : 
 */
import { GameAssets } from "../const/GameAssets"

export class WorldUI {
    static addWorldUI(location: Type.Vector, rotate: Type.Vector, scale: Type.Vector, text: string, color: string) {
        let widget = <Gameplay.UIWidget>Core.GameObject.spawnGameObject(GameAssets.WORLD_UI)
        widget.widgetSpace = Gameplay.WidgetSpaceMode.World
        widget.pivot = new Type.Vector2(0.5, 0.5)
        widget.setUI("7D7482244BFD204497B6C7BAAAA109C4")
        widget.drawSize = new Type.Vector2(500, 150);
        widget.worldLocation = location
        widget.worldRotation = new Type.Rotation(rotate)
        widget.worldScale = scale
        let _text = <UI.TextBlock>widget.getUI().findChildByPath("Canvas/mText")
        _text.text = text;
        _text.fontColor = new Type.LinearColor(Type.LinearColor.colorHexToLinearColor(color))
        widget.refresh()
    }
} 