import { Singleton } from "odin";
import { GameConfig } from "../../../config/GameConfig";
import { GameAssets } from "../../../const/GameAssets";

/**
 * @Author       : 田可成
 * @Date         : 2022-09-04 12:20:22
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-12-27 10:59:00
 * @FilePath     : \ilovethemountains\JavaScripts\modules\gameModule\skyBox\SkyBoxManager.ts
 * @Description  : 
 */
@Singleton()
export class SkyBoxManager {
    public static instance: SkyBoxManager
    private skyObj: Gameplay.SkyBox;

    init() {
        Core.GameObject.asyncFind(GameAssets.SkyBox).then((obj) => {
            this.skyObj = obj as Gameplay.SkyBox;
        })
    }

    index: number = 1;
    startDayNight() {
        if (!this.skyObj) {
            setTimeout(() => {
                this.startDayNight()
            }, 1000);
        }
        let timeCfg = GameConfig.Time.getElement(this.index)
        let nowSkyDomeIntensity = this.skyObj.getSkyDomeIntensity()
        let nowSkyDomeHorizontalFallOff = this.skyObj.getSkyDomeHorizontalFallOff()
        let time = 0;
        new Extension.TweenUtil.Tween({ a: nowSkyDomeIntensity, b: nowSkyDomeHorizontalFallOff }).to({ a: timeCfg.SkyBoxBright, b: timeCfg.Horizon }, timeCfg.Time * 1000).onUpdate(v => {
            time++;
            if (time > 1000) {
                time = 0;
                this.skyObj.setSkyDomeIntensity(v.a)
                this.skyObj.setSkyDomeHorizontalFallOff(v.b)
            }
        }).onComplete(() => {
            this.index++;
            if (this.index > GameConfig.Time.getAllElement().length) this.index = 1;
            this.skyObj.setIsEnableCloud(timeCfg.CloudOpen);
            this.skyObj.setIsEnableSun(timeCfg.SunOpen);
            this.skyObj.setIsEnableMoon(timeCfg.MoonOpen)
            this.skyObj.setIsEnableStar(timeCfg.StarOpen);
            this.startDayNight()
        }).start()
    }
}