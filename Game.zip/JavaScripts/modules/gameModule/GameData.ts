import { DataInfo, ModuleData, OldAPI_Action1 } from "odin";

/**
 * @Author       : 田可成
 * @Date         : 2022-07-20 10:08:29
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-10-30 18:47:42
 * @FilePath     : \ilovethemountains\JavaScripts\modules\gameModule\GameData.ts
 * @Description  : 
 */
export class GameData extends DataInfo {
    public gold: number = 0
}

export class GameDataHelper extends ModuleData<GameData>{

    public readonly OnGoldNumChange: OldAPI_Action1<number> = new OldAPI_Action1();  //金币变化调用
    public constructor() {
        super(GameData);
    }

    public AddGold(value: number) {
        this.dataInfo.gold += value
    }

    public GetGoldNum(): number {
        return this.dataInfo.gold
    }
}