﻿import GameStart_Generate from "../../ui-generate/game/GameStart_generate";
import { Util } from "../../util/Util";
import P_LoginUI from "./P_LoginUI";

/**
 * @Author       : 田可成
 * @Date         : 2022-08-25 20:05:54
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-12-26 14:03:17
 * @FilePath     : \ilovethemountains\JavaScripts\modules\gameModule\P_GameStart.ts
 * @Description  : 
 */
export default class P_GameStart extends GameStart_Generate {

	protected onStart(): void {
		this.startBtn.onClicked.add(() => {
			Util.playSound(16)
			Extension.UIManager.instance.show(P_LoginUI)
			this.visible = false;
		});
	}
}
