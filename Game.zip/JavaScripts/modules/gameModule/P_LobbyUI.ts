import { DataCenterC, ModuleManager } from "odin";
import ScoreMgr from "../../../Prefabs/PlayerScore/Script/ScoreMgr";
import { GameConfig } from "../../config/GameConfig";
import { globalLanguage, LanguageIndex } from "../../const/GlobleLanguage";
import { ClientEvents } from "../../const/LocalEvents";
import Lobby_Generate from "../../ui-generate/game/Lobby_generate";
import RankingItem_Generate from "../../ui-generate/game/RankingItem_generate";
import { P_SetUp_UI } from "../../ui/P_SetUpUI";
import { Util } from "../../util/Util";
import { P_BagMain } from "../commonModules/bagModule/P_Bag";
import { FacadModuleC } from "../commonModules/dress/FacadModule";
import { GameDataHelper } from "./GameData";

export default class P_LobbyUI extends Lobby_Generate {

    onStart() {
        DataCenterC.instance.getModuleData(GameDataHelper).OnGoldNumChange.add((goldnum: number) => this.mGoldCnt.text = goldnum.toString())

        this.mJumpBtn.onPressed.add(() => {
            Util.playSound(19)
            let player = Gameplay.getCurrentPlayer();
            player.character.jump();
            Util.uploadMGS("ts_action_click", "玩家点击跳跃按钮", { button: "jump" });
        })

        this.shopBtn.onClicked.add(() => {
            Util.playSound(16)
            ModuleManager.instance.getModule(FacadModuleC).openFacad();
            Util.uploadMGS("ts_action_click", "点击商店入口按钮", { button: "shop" });
        });

        this.mEmergency.onClicked.add(() => {
            Util.playSound(16)
            Events.dispatchLocal(ClientEvents.Ev_ReturnBornPoint);
            Util.uploadMGS("ts_action_click", "玩家点击重生按钮", { button: "back" });

        })

        this.mSetUp.onClicked.add(() => {
            Util.playSound(16)
            Extension.UIManager.instance.show(P_SetUp_UI)
            Extension.UIManager.instance.hide(P_BagMain)
            this.visible = false
        });
        this.registerEvents();
    }

    private registerEvents(): void {
        Events.addLocalListener(ClientEvents.Ev_RefreshRank_Client, () => this.refreshRank());
        Events.addLocalListener(ClientEvents.Ev_RefreshProperty, (param: any[]) => {
            let prePercent = this.hpProgressBar.percent
            this.strProgressBar.percent = (param[0] / GameConfig.PlayerConfig.getElement(1).MaxStamina);
            this.hpProgressBar.percent = (param[1] / GameConfig.PlayerConfig.getElement(1).MaxHP);

            let strTxt: string = param[0] == 100 ? param[0].toFixed(0) : param[0].toFixed(1);
            let hpTxt: string = param[1] == 100 ? param[1].toFixed(0) : param[1].toFixed(1);

            this.strTxt.text = (strTxt + "/" + GameConfig.PlayerConfig.getElement(1).MaxStamina.toString());
            this.hpTxt.text = (hpTxt + "/" + GameConfig.PlayerConfig.getElement(1).MaxHP.toString());

            let aftPercent = this.hpProgressBar.percent
            if (aftPercent < prePercent) {
                this.onHurt();
            }
        });
        Events.addLocalListener(ClientEvents.EV_ResetGame, () => {
            this.mEmergency.onClicked.clear();
            this.mCSTXT.text = globalLanguage.getLanguage("Setup_Title_text_2")
            this.mEmergency.onClicked.add(() => {
                Util.playSound(16)
                Events.dispatchLocal(ClientEvents.Ev_ReturnBornPoint)
            })
        });
        Events.addLocalListener(ClientEvents.EV_ClearGame, () => {
            this.mEmergency.onClicked.clear();
            this.mCSTXT.text = globalLanguage.getLanguage(LanguageIndex.返回大本营)
            this.mEmergency.onClicked.add(() => {
                Util.playSound(16)
                Events.dispatchLocal(ClientEvents.Ev_ReturnCamp);
                Events.dispatchLocal(ClientEvents.EV_ResetGame);
            })
        });
        Events.addLocalListener(ClientEvents.EV_EnterGuide, () => {
            this.mRankPanel.visibility = UI.SlateVisibility.Collapsed
            this.mSetUp.visibility = UI.SlateVisibility.Collapsed
            this.mSZTxt.visibility = UI.SlateVisibility.Collapsed
            this.mCSTXT.visibility = UI.SlateVisibility.Collapsed
            this.mCSTXT_1.visibility = UI.SlateVisibility.Collapsed
            this.mEmergency.visibility = UI.SlateVisibility.Collapsed
            this.shopBtn.visibility = UI.SlateVisibility.Collapsed
        })

        Events.addLocalListener(ClientEvents.EV_ExitGuide, () => {
            this.mRankPanel.visibility = UI.SlateVisibility.Visible
            this.mSetUp.visibility = UI.SlateVisibility.Visible
            this.mSZTxt.visibility = UI.SlateVisibility.Visible
            this.mCSTXT.visibility = UI.SlateVisibility.Visible
            this.mCSTXT_1.visibility = UI.SlateVisibility.Visible
            this.mEmergency.visibility = UI.SlateVisibility.Visible
            this.shopBtn.visibility = UI.SlateVisibility.Visible
        })

    }

    protected onShow(): void {
        this.mGoldCnt.text = DataCenterC.instance.getModuleData(GameDataHelper).GetGoldNum().toString()
    }

    private scoreItemArr: RankingItem_Generate[] = new Array<RankingItem_Generate>();

    private refreshRank() {
        let srcPool = ScoreMgr.instance.srcPool;
        srcPool.sort((a, b) => {
            if (a.topCount > b.topCount) {
                return -1;
            } else if (a.topCount < b.topCount) {
                return 1;
            } else if (a.topCount == b.topCount) {
                if (a.savePoint > b.savePoint) {
                    return -1;
                }
                else {
                    return 1;
                }
            }
        });

        let count = 0;
        srcPool.forEach(src => {
            if (src.pid > 0) {
                // MAKER: 动态创建积分榜单元格并添加为排行榜画布子组件
                count++;
                let item: RankingItem_Generate;
                if (this.scoreItemArr.length >= count) {
                    item = this.scoreItemArr[count - 1];
                }
                else {
                    item = Extension.UIManager.instance.create(RankingItem_Generate)
                    this.scoreItemArr.push(item);
                    this.rankCanvas.addChild(item.uiObject);
                    item.uiObject.slot.size = itemSize
                }

                item.rankTxt.text = count.toString()
                item.nameTxt.text = src.nickName
                item.scoreTxt.text = src.savePoint.toString()
                item.numberTxt.text = src.topCount.toString()
                item.heightTxt.text = src.height.toFixed(2) + "m"

                if (item.uiObject.visibility == UI.SlateVisibility.Collapsed)
                    item.uiObject.visibility = UI.SlateVisibility.HitTestInvisible

                if (src.pid == Gameplay.getCurrentPlayer().getPlayerID()) {
                    item.nameTxt.setFontColorByHex("2F2484FF")
                    item.rankTxt.fontColor = new Type.LinearColor(1, 1, 0)
                    item.scoreTxt.fontColor = new Type.LinearColor(1, 1, 0)
                    item.numberTxt.fontColor = new Type.LinearColor(1, 1, 0)
                    item.heightTxt.fontColor = new Type.LinearColor(1, 1, 0)

                } else {
                    item.rankTxt.fontColor = new Type.LinearColor(1, 1, 1)
                    item.nameTxt.fontColor = new Type.LinearColor(1, 1, 1)
                    item.scoreTxt.fontColor = new Type.LinearColor(1, 1, 1)
                    item.numberTxt.fontColor = new Type.LinearColor(1, 1, 1)
                    item.heightTxt.fontColor = new Type.LinearColor(1, 1, 1)

                }
            }
        });

        for (let i = count; i < this.scoreItemArr.length; i++) {
            this.scoreItemArr[i].uiObject.visibility = UI.SlateVisibility.Collapsed
        }

        this.rankCanvas.slot.position = Type.Vector2.zero
        this.rankCanvas.slot.size = new Type.Vector2(600, 40 * count + (count - 1) * 10)
    }

    onHurt() {
        this.mHurt.renderOpacity = 0
        new Extension.TweenUtil.Tween({ a: 0 }).to({ a: 1 }, 200).onUpdate(v => {
            this.mHurt.renderOpacity = v.a
        }).onComplete(() => {
            new Extension.TweenUtil.Tween({ a: 1 }).to({ a: 0 }, 200).onUpdate(v => {
                this.mHurt.renderOpacity = v.a
            }).start()
        }).start()

    }
}
const itemSize = new Type.Vector2(600, 40);