/**
 * @Author       : 田可成
 * @Date         : 2022-09-01 00:56:36
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-12-26 13:24:44
 * @FilePath     : \ilovethemountains\JavaScripts\modules\gameModule\GameModule_Server.ts
 * @Description  : 
 */
import { DataCenterS, ModuleS } from "odin";
import ScoreMgr from "../../../Prefabs/PlayerScore/Script/ScoreMgr";
import { GameConfig } from "../../config/GameConfig";
import { GlobalVas } from "../../const/GlobalDefine";
import { Util } from "../../util/Util";
import { PlayDataHelper } from "../playModule/PlayData";
import { GameDataHelper } from "./GameData";
import { GameModule_Client } from "./GameModule_Client";


export class GameModule_Server extends ModuleS<GameModule_Client, GameDataHelper>{
    private players: number[];
    onStart() {
        this.players = []
        DataCenterS.instance.onPlayerLeft.add((player: Gameplay.Player) => {
            player.character.characterName = ""
            let playerid = player.getPlayerID()
            if (this.players.indexOf(playerid) != -1) {
                this.players.splice(this.players.indexOf(playerid), 1)
                ScoreMgr.instance.onPlayerLeft(playerid);
            }
        })
    }

    net_PlayerLogin_S(nickName: string, player?: Gameplay.Player) {
        let pid = player.getPlayerID()
        if (this.players.indexOf(pid) == -1) {
            this.players.push(pid)
            ScoreMgr.instance.onPlayerJoin(pid, nickName, DataCenterS.instance.getModuleData(pid, PlayDataHelper).getTopCount())
        }
        player.character.characterName = nickName

        player.character.worldLocation = Util.randomCirclePoint(GlobalVas.bornPoint, GlobalVas.bornPointRadius)
        this.callClientFun(player, this.client.net_PlayerLogin_C())
    }

    climbTime: number = 0
    onUpdate(dt: number): void {
        this.climbTime += dt;
        if (this.climbTime >= GameConfig.PlayerConfig.getElement(1).climbTime) {
            this.players.forEach((pid) => {
                ScoreMgr.instance.refreshHeight(pid, Gameplay.getPlayer(pid).character.worldLocation.z);
            });
            this.climbTime = 0;
        }
    }

    public net_AddGold(value: number) {
        this.currentData.AddGold(value)
        this.currentData.saveData(true).OnGoldNumChange.call(this.currentData.GetGoldNum())
    }
}

