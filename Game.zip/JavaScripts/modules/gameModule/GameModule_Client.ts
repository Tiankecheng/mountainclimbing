import { ModuleC, ModuleManager, oTrace } from "odin";
import { SavePointEvent } from "../../../Prefabs/Bonfire/Script/SavePoint";
import { TrrEvent } from "../../../Prefabs/EventTrr/Script/EventTrr";
import { InteractiveEvent } from "../../../Prefabs/Interactive/Script/InteractiveObj";
import { PickUpEvent } from "../../../Prefabs/PickUp/Script/PickUp";
import { GameConfig } from "../../config/GameConfig";
import { GlobalVas } from "../../const/GlobalDefine";
import Skip_Generate from "../../ui-generate/commonUI/Skip_generate";
import { scheduler } from "../../util/Scheduler";
import { Util } from "../../util/Util";
import { WorldUI } from "../../util/WorldUI";
import { BagModule_Clinet } from "../commonModules/bagModule/BagModule_Clinet";
import { P_BagMain } from "../commonModules/bagModule/P_Bag";
import P_InteractUI from "../commonModules/bagModule/P_InteractUI";
import P_PickUp from "../commonModules/bagModule/P_PickUp";
import { GMManager } from "../commonModules/gm/GMManager";
import GuideModule_Client from "../commonModules/guide/GuideModule_Client";
import { EventManager_C } from "../playModule/event/EventManager_C";
import { GameDataHelper } from "./GameData";
import { GameModule_Server } from "./GameModule_Server";
import P_GameStart from "./P_GameStart";
import P_LobbyUI from "./P_LobbyUI";
import { SkyBoxManager } from "./skyBox/SkyBoxManager";

export class GameModule_Client extends ModuleC<GameModule_Server, GameDataHelper>{
    /**要等到一些逻辑处理完 */
    initOver: boolean = false;
    private _gmModule: GuideModule_Client;
    private _flagMap: Map<number, Core.GameObject> = new Map()
    private _cameraPoint: Core.GameObject

    onStart(): void {
        this.init();
        this.sendLogin();

        Extension.UIManager.instance.show(P_GameStart)
        this.eventInit();

    }

    eventInit() {
        let pickupUI = Extension.UIManager.instance.getUI(P_PickUp)
        Events.addLocalListener(SavePointEvent.SP_OnEnterTrriger, (params: any) => {
            Extension.SoundManager.getInstance().stopAllSound();
            Util.playSound(8)
            Util.uploadMGS("ts_game_over", "玩家靠近篝火恢复体力时", {});
            GlobalVas.inArea = false;
            GlobalVas.staminaRevert = params[0];
        })

        Events.addLocalListener(SavePointEvent.SP_OnLeaveTrriger, () => {
            Extension.SoundManager.getInstance().stopAllSound();
            Util.playSound(9)
            GlobalVas.inArea = true
        })

        Events.addLocalListener(PickUpEvent.PU_OnEnterTrriger, (params: any) => {
            if (GlobalVas.g_GameIsGuide) return;
            let itemCnt = ModuleManager.instance.getModule(BagModule_Clinet).getItemCnt(params[0])
            if (params[6] && itemCnt != 0) {
                Extension.UIManager.instance.show(P_PickUp, params)
            }
            if (!params[6] && itemCnt == 0) {
                Extension.UIManager.instance.show(P_PickUp, params)
            }
        })

        Events.addLocalListener(PickUpEvent.PU_OnLeaveTrriger, () => {
            pickupUI.visible = false
        })

        Events.addLocalListener(TrrEvent.Trr_OnEnterTrriger, (params: any) => {
            EventManager_C.instance.executeEvent(params[0], params[1], params[2], params[3])
        })

        Events.addLocalListener(InteractiveEvent.IE_OpenBag, (flag) => {
            if (flag) {
                Extension.UIManager.instance.show(P_BagMain)
            } else {
                Extension.UIManager.instance.hide(P_BagMain)
            }
        });

        Events.addLocalListener(InteractiveEvent.IE_OpenInteractUI, (flag) => {
            if (flag) {
                Extension.UIManager.instance.show(P_InteractUI)
            } else {
                Extension.UIManager.instance.hide(P_InteractUI)
            }
        });

    }

    /**初始化场景要找的物体 */
    async init() {
        if (this.initOver) return
        this._gmModule = ModuleManager.instance.getModule(GuideModule_Client);
        Gameplay.getCurrentPlayer().character.enableMove = false
        Core.GameObject.asyncFind(GlobalVas.startPoint).then((obj) => {
            this.changeCamera(obj, false, GameConfig.PlayerConfig.getElement(1).CameraRotation, GameConfig.PlayerConfig.getElement(1).CameraHight);
            GameConfig.Flag.getAllElement().forEach(flagCfg => {
                Core.GameObject.asyncFind(flagCfg.Guid).then((flag) => {
                    let flagClone = flag.clone();
                    flagClone.attachToGameObject(obj);
                    flagClone.setRelativeLocation(flagCfg.PosOffset)
                    flagClone.setRelativeRotation(new Type.Rotation(flagCfg.Rotate))
                    flagClone.setRelativeScale(flagCfg.Scale)
                    this._flagMap.set(flagCfg.ID, flagClone);
                    flagClone.setVisibility(Type.PropertyStatus.Off)
                })
            });
        });

        Core.GameObject.asyncFind("699F2133441803408CD9B7BC9625A6C4").then((point) => {
            this._cameraPoint = point;
        })

        //初始化3DUI
        GameConfig.WorldUI.getAllElement().forEach((worldUI) => {
            WorldUI.addWorldUI(worldUI.Pos, worldUI.Rotate, worldUI.Scale, worldUI.Text, worldUI.Color)
        })
        //初始化天空盒实例
        SkyBoxManager.instance.init();
        this.initOver = true;
        oTrace("初始化是否无异常" + this.initOver);
    }

    /**发送登录 */
    sendLogin() {
        let nickName = Service.MGSService.getInstance().getNickName()
        this.server.net_PlayerLogin_S(nickName)
    }

    /**登录返回 */
    net_PlayerLogin_C() {
        this.currentPlayer.character.worldRotation = Type.Rotation.zero
        GMManager.instance.show()
        Extension.UIManager.instance.show(P_GameStart)
        ModuleManager.instance.getModule(BagModule_Clinet).reqDeleteAllItem();
        let guideID = this._gmModule.getCurGuideId()
        this._gmModule.setGuideEvent(guideID ? guideID : 1);
        guideID ? null : this._gmModule.triggerGuide(1)
    }

    showFlag(curIndex: number, index: number) {
        let curFlag = this._flagMap.get(curIndex)
        let flag = this._flagMap.get(index);
        curFlag.setVisibility(Type.PropertyStatus.Off)
        flag.setVisibility(Type.PropertyStatus.On)
    }

    cameraMotion(index: number) {
        Extension.SoundManager.getInstance().playBGM(GameConfig.Audio.getElement(20).ResGUID)
        Util.stopSound(7)
        this.changeCamera(this._cameraPoint, false, new Type.Vector(0, -30, 0), new Type.Vector(-8000, 0, 0))
        let tweens = [];
        let skipUI = Extension.UIManager.instance.show(Skip_Generate)
        skipUI.mBtn.onClicked.add(() => {
            tweens.forEach(tween => {
                tween.stop();
            });
            this.changeCamera(this.currentPlayer.character, true, new Type.Vector(0, -20, 0))
            this.gameStart(index)
            skipUI.visible = false;
        })
        tweens.push(new Extension.TweenUtil.Tween({
            a: new Type.Vector(-870.92, 10391.21, 24093.51),
            b: new Type.Rotation(0, -30, 0)
        }).to({
            a: new Type.Vector(13024.94, 1167.06, 13669.9),
            b: new Type.Rotation(0, -30, 360)
        }, 5000).onUpdate(v => {
            this._cameraPoint.worldLocation = v.a
            this.currentPlayer.character.cameraSystem.setOverrideCameraRotation(v.b)
        }).onComplete(() => {
            tweens.push(new Extension.TweenUtil.Tween({
                a: new Type.Vector(13024.94, 1167.06, 13669.9),
                b: new Type.Rotation(0, -30, 360)
            }).to({
                a: new Type.Vector(-7536.43, -10366.09, 8449.38),
                b: new Type.Rotation(0, -30, 540)
            }, 5000).onUpdate(v => {
                this._cameraPoint.worldLocation = v.a
                this.currentPlayer.character.cameraSystem.setOverrideCameraRotation(v.b)
            }).onComplete(() => {
                tweens.push(new Extension.TweenUtil.Tween({
                    a: new Type.Vector(-7536.43, -10366.09, 8449.38),
                    b: new Type.Rotation(0, -30, 540),
                    c: new Type.Vector(-5000, 0, 0)
                }).to({
                    a: GlobalVas.bornPoint,
                    b: new Type.Rotation(0, -30, 720),
                    c: Type.Vector.zero
                }, 5000).onUpdate(v => {
                    this._cameraPoint.worldLocation = v.a
                    this.currentPlayer.character.cameraSystem.setOverrideCameraRotation(v.b)
                    this.currentPlayer.character.cameraSystem.socketOffset = v.c;
                }).onComplete(() => {
                    this.changeCamera(this.currentPlayer.character, true, new Type.Vector(0, -20, 0))
                    this.gameStart(index)
                    skipUI.visible = false
                }).start())
            }).start())
        }).start())

        tweens.push(new Extension.TweenUtil.Tween({
            a: new Type.Vector(-8000, 0, 0),
        }).to({
            a: new Type.Vector(-5000, 0, 0),
        }, 5000).onUpdate(v => {
            this.currentPlayer.character.cameraSystem.socketOffset = v.a;
        }).start())
    }

    gameStart(index: number) {
        let flag = this._flagMap.get(index);
        flag.setVisibility(Type.PropertyStatus.Off)
        GlobalVas.flagIndex = index;
        Extension.SoundManager.getInstance().stopBGM()
        Util.playSound(7)
        SkyBoxManager.instance.startDayNight()
        Extension.UIManager.instance.show(P_LobbyUI);
        ModuleManager.instance.getModule(BagModule_Clinet).addItemByCfg(7);
        ModuleManager.instance.getModule(BagModule_Clinet).openBag();
        Gameplay.getCurrentPlayer().character.enableMove = true;
        let guideID = this._gmModule.getCurGuideId()
        ModuleManager.instance.getModule(GuideModule_Client).triggerGuide(guideID > 3 ? guideID : 3)
    }

    plugFlag(pos: Type.Vector, rotate: Type.Vector, scale: Type.Vector) {
        let flag = this._flagMap.get(GlobalVas.flagIndex)
        flag.detachFromGameObject();
        flag.setVisibility(Type.PropertyStatus.On)
        flag.worldLocation = pos;
        flag.worldRotation = new Type.Rotation(rotate)
        flag.worldScale = scale;
    }

    /**
     * @description: 设置相机看向的位置
     * @param {MWCore} target 目标
     * @param {Type} CameraRotation 摄像机旋转
     * @param {Type} CameraOffset 摄像机偏移
     * @return {*}
     */
    changeCamera(target: Core.GameObject, isFollow: boolean, CameraRotation: Type.Vector = Type.Vector.zero, CameraOffset: Type.Vector = Type.Vector.zero) {
        this.currentPlayer.character.cameraSystem.followTargetInterpSpeed = 0
        this.currentPlayer.character.cameraSystem.setCameraFollowTarget(target)
        if (!isFollow) {
            this.currentPlayer.character.cameraSystem.enableCameraCollison = false
            this.currentPlayer.character.cameraSystem.cameraRotationMode = Gameplay.CameraRotationMode.RotationControl
            this.currentPlayer.character.cameraSystem.setOverrideCameraRotation(new Type.Rotation(CameraRotation));
            this.currentPlayer.character.cameraSystem.socketOffset = CameraOffset;
        } else {
            this.currentPlayer.character.cameraSystem.enableCameraCollison = true
            this.currentPlayer.character.cameraSystem.setOverrideCameraRotation(new Type.Rotation(CameraRotation));
            scheduler.tickStart(() => {
                this.currentPlayer.character.cameraSystem.resetOverrideCameraRotation()
            })
            this.currentPlayer.character.cameraSystem.socketOffset = CameraOffset;
        }
    }

    private ismove: boolean = false
    onUpdate(dt: number): void {
        if (Gameplay.getCurrentPlayer().character.isJumping) {
            this.ismove = false
            Extension.SoundManager.getInstance().stopSound(GameConfig.Audio.getElement(18).ResGUID)
        }
        if (Gameplay.getCurrentPlayer().character.isMoving) {
            if (!this.ismove && !Gameplay.getCurrentPlayer().character.isJumping) {
                Util.playSound(18) //走路音效
                if (!this.initOver) {
                    this.init()
                }
                this.ismove = true
            }
        } else {
            this.ismove = false
            Extension.SoundManager.getInstance().stopSound(GameConfig.Audio.getElement(18).ResGUID)
        }
    }

    addGold(value: number) {
        this.server.net_AddGold(value)
    }
}
