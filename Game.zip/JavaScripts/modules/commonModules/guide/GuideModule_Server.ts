/**
 * @Author       : 田可成
 * @Date         : 2022-08-02 13:23:29
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-10-30 15:54:14
 * @FilePath     : \ilovethemountains\JavaScripts\modules\guideModule\GuideModule_Server.ts
 * @Description  : 
 */

import { GuideDataHelper, GuideModuleC, GuideModuleS } from "module_guide";
import { ModuleManager } from "odin";

class GuideModule_Server extends GuideModuleS {

    onStart(): void {
        ModuleManager.instance.register(GuideModuleS, GuideModuleC, GuideDataHelper);
    }
}
export default GuideModule_Server