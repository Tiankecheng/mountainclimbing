import { GuideDataHelper, GuideModuleC, GuideModuleS, GuideModuleView } from "module_guide";
import { ModuleManager, oTraceError } from "odin";
import { GameConfig } from "../../../config/GameConfig";
import { globalLanguage, LanguageIndex } from "../../../const/GlobleLanguage";
import { ClientEvents } from "../../../const/LocalEvents";
import GuideCompleteUI_Generate from "../../../ui-generate/guideModule/GuideCompleteUI_generate";
import GuideReadyUI_Generate from "../../../ui-generate/guideModule/GuideReadyUI_generate";
import GuideTipsUI_Generate from "../../../ui-generate/guideModule/GuideTipsUI_generate";
import P_Tips from "../../../ui/P_Tips";
import { Util } from "../../../util/Util";
import { GameModule_Client } from "../../gameModule/GameModule_Client";
import P_GameStart from "../../gameModule/P_GameStart";
import P_LobbyUI from "../../gameModule/P_LobbyUI";
import P_LoginUI from "../../gameModule/P_LoginUI";
import { EventManager_C } from "../../playModule/event/EventManager_C";
import P_EventDecUI from "../../playModule/event/P_EventDecUI";
import P_EventUI from "../../playModule/event/P_EventUI";
import { PlayModule_Client } from "../../playModule/PlayModule_Client";
import { BagModule_Clinet } from "../bagModule/BagModule_Clinet";
import { P_BagMain } from "../bagModule/P_Bag";
import P_PickUp from "../bagModule/P_PickUp";

class GuideModule_Client extends GuideModuleC {
    private _tipsMap: Map<number, GuideTipsUI_Generate> = new Map();
    private _tipsPool: GuideTipsUI_Generate[] = [];
    private _guideUI: GuideModuleView
    onStart(): void {
        ModuleManager.instance.register(GuideModuleS, GuideModuleC, GuideDataHelper);
        ModuleManager.instance.getModule(GuideModuleC).reSetToTargetPosDistance(300);
        this.reSetCharGo(Gameplay.getCurrentPlayer().character)
        this._guideUI = Extension.UIManager.instance.getUI(GuideModuleView)
        this.guideComplateAction.add((guideId: number) => {
            [1].includes(guideId) ? this.triggerGuide(guideId + 1) : null
            if (guideId == 2) {
                Util.uploadMGS("ts_tutorial_step", "玩家点击选择旗帜时", { tutorial_step: 1 });
            }
            if (guideId == 5) {
                Util.uploadMGS("ts_tutorial_step", "玩家点击使用按钮时", { tutorial_step: 4 });
            }
            if (guideId == 6) {
                Util.uploadMGS("ts_tutorial_step", "玩家走出营地触发第一个事件时", { tutorial_step: 5 });
            }
            if (guideId == 7) {
                Util.uploadMGS("ts_tutorial_step", "玩家回到帐篷拾取物品时", { tutorial_step: 7 });
                //FIXME: 引导7未正确结束
            }
        });
    }

    setGuideEvent(guideID: number) {
        switch (guideID) {
            case 1:
                Extension.UIManager.instance.getUI(P_GameStart)
                this.setEventByCfg(1, () => { Events.dispatchLocal(ClientEvents.EV_EnterGuide); return true; })
            case 2:
                Extension.UIManager.instance.getUI(P_LoginUI)
                this.setEventByCfg(2, () => { Events.dispatchLocal(ClientEvents.EV_EnterGuide); return true })
            case 3:
                Extension.UIManager.instance.getUI(P_LobbyUI)
                let guideTime = 50;
                this.setEventByCfg(3, () => {
                    Events.dispatchLocal(ClientEvents.EV_EnterGuide)
                    Gameplay.getCurrentPlayer().character.enableMove = false;
                    ModuleManager.instance.getModule(PlayModule_Client).climber.property.stamina -= GameConfig.PlayerConfig.getElement(1).MaxStamina / 2;
                    ModuleManager.instance.getModule(PlayModule_Client).climber.property.hp -= GameConfig.PlayerConfig.getElement(1).MaxHP / 2;
                    ModuleManager.instance.getModule(PlayModule_Client).refreshUI();
                    return true
                }, () => {
                    guideTime++;
                    if (guideTime >= 30) {
                        guideTime = 0;
                        ModuleManager.instance.getModule(PlayModule_Client).climber.property.stamina -= 10;
                        ModuleManager.instance.getModule(PlayModule_Client).refreshUI();
                    }
                    if (ModuleManager.instance.getModule(PlayModule_Client).climber.property.stamina <= 0) {
                        return true;
                    }
                }, () => {
                    guideTime++;
                    if (guideTime >= 30) {
                        guideTime = 0;
                        ModuleManager.instance.getModule(PlayModule_Client).climber.property.hp -= 10;
                        ModuleManager.instance.getModule(PlayModule_Client).refreshUI();
                    }
                    if (ModuleManager.instance.getModule(PlayModule_Client).climber.property.hp <= 20) {
                        guideTime = 0;
                        Gameplay.getCurrentPlayer().character.enableMove = true;
                        this.triggerGuide(4)
                        return true;
                    }
                })
            case 4:
                Extension.UIManager.instance.getUI(P_PickUp)
                this.setEventByCfg(4, () => { Events.dispatchLocal(ClientEvents.EV_EnterGuide); return true }, () => {
                    Gameplay.getCurrentPlayer().character.enableMove = false;
                    Extension.UIManager.instance.show(P_PickUp, [1])
                    return true
                }, () => {
                    Util.uploadMGS("ts_tutorial_step", "玩家点击一个拾取按钮时", { tutorial_step: 3 });
                    Gameplay.getCurrentPlayer().character.enableMove = true;
                    return true
                }, () => {
                    Gameplay.getCurrentPlayer().character.enableMove = false;
                    Extension.UIManager.instance.show(P_PickUp, [2])
                    return true
                }, () => {
                    Gameplay.getCurrentPlayer().character.enableMove = true;
                    this.triggerGuide(5)
                    return true
                })
            case 5:
                Extension.UIManager.instance.getUI(P_BagMain)
                this.setEventByCfg(5, () => {
                    Events.dispatchLocal(ClientEvents.EV_EnterGuide)
                    if (guideID == 5) ModuleManager.instance.getModule(BagModule_Clinet).addItemByCfg(1)
                    return true
                }, () => {
                    Events.dispatchLocal(ClientEvents.EV_EnterGuide)
                    ModuleManager.instance.getModule(BagModule_Clinet).showItem()
                    return true;
                }, () => {
                    let guideReady = Extension.UIManager.instance.show(GuideReadyUI_Generate)
                    guideReady.mBtn.onClicked.add(() => { guideReady.visible = false; this.triggerGuide(6) })
                    return true;
                })
            case 6:
                Extension.UIManager.instance.getUI(P_EventUI)

                this.setEventByCfg(6, () => { Events.dispatchLocal(ClientEvents.EV_EnterGuide); return true }, () => {
                    EventManager_C.instance.executeEvent(0, "1,3", 3, "58C3FA1240E40A0DC44B5488137FD6C1")
                    return true
                })
            case 7:
                Extension.UIManager.instance.getUI(P_EventDecUI)
                this.setEventByCfg(7, () => {
                    if (guideID == 7) Extension.UIManager.instance.show(P_EventDecUI, 1)
                    Util.uploadMGS("ts_tutorial_step", "玩家点击选择按钮时", { tutorial_step: 6 });
                    return true
                });
            case 8:
                Extension.UIManager.instance.getUI(P_LobbyUI)
                this.setEventByCfg(8, () => {
                    Events.dispatchLocal(ClientEvents.EV_ExitGuide)
                    ModuleManager.instance.getModule(PlayModule_Client).climber.property.stamina += GameConfig.PlayerConfig.getElement(1).MaxStamina;
                    ModuleManager.instance.getModule(PlayModule_Client).climber.property.hp += GameConfig.PlayerConfig.getElement(1).MaxHP;
                    ModuleManager.instance.getModule(PlayModule_Client).refreshUI();
                    return true
                }, () => {
                    let guideComplete = Extension.UIManager.instance.getUI(GuideCompleteUI_Generate)
                    guideComplete.mBtn.onClicked.add(() => { Extension.UIManager.instance.hide(GuideCompleteUI_Generate) })
                    Extension.UIManager.instance.show(GuideCompleteUI_Generate)
                    let str = Util.formatString(globalLanguage.getLanguage(LanguageIndex["增加{0}金币"]), 50)
                    P_Tips.show(str);
                    ModuleManager.instance.getModule(GameModule_Client).addGold(50)
                    return true;
                })
        }
    }

    private setEventByCfg(ID: number, ...func: any[]) {
        const guide = this.addGuideStageHandle(ID);
        if (!guide) return
        const guideCfg = GameConfig.Guide.getElement(ID);
        let guideUI: UI.UIBehaviour = null
        if (guideCfg.Uiname && Extension.UIManager.instance["creatPanleMap"].has(guideCfg.Uiname)) {
            guideUI = Extension.UIManager.instance["creatPanleMap"].get(guideCfg.Uiname)[0];
        } else {
            oTraceError("未找到" + guideCfg.Uiname)
            return;
        }
        let eventNum = 1;
        let funcNum = 0;
        while (guideCfg["Event" + eventNum] != null) {
            if (guideCfg["Event" + eventNum].length != 1 && guideCfg["Event" + eventNum].indexOf("|") == -1) {
                if (guideCfg["Event" + eventNum].indexOf("_") != -1) {
                    const uiName = guideCfg["Event" + eventNum].split("_");
                    guide.addBindUIByCondition(guideUI[uiName[0]], func[funcNum])
                    funcNum++;
                } else {
                    guide.addBindUI(guideUI[guideCfg["Event" + eventNum]])
                }
            } else if (guideCfg["Event" + eventNum].length == 1) {
                if (func[funcNum]) {
                    guide.addCondition(func[funcNum])
                }
                funcNum++;
            } else {
                const strs = guideCfg["Event" + eventNum].split("|");
                let pos = new Type.Vector(Number(strs[0]), Number(strs[1]), Number(strs[2]));
                guide.addBindWorldPos(pos)
            }
            const _eventNum = eventNum
            const _ID = ID;
            guide.addRunFunc(() => {
                this.addTips(_ID, _eventNum);
                this.removeTips(_ID, _eventNum);
            });
            eventNum++;
        }
    }

    addTips(ID: number, eventNum: number) {
        GameConfig.GuideUI.getAllElement().forEach(_guideUICfg => {
            if (_guideUICfg.StartEvent[0] == ID && _guideUICfg.StartEvent[1] == eventNum) {
                const tempSize = Type.Vector2.zero
                let tips: GuideTipsUI_Generate = this.creatTips()

                tips.mText.text = _guideUICfg.Text
                tips.mText.fontSize = _guideUICfg.TextSize
                tempSize.x = _guideUICfg.TextPos[0], tempSize.y = _guideUICfg.TextPos[1]
                tips.mText.slot.position = tempSize
                tempSize.x += 1200; tempSize.y += 166
                tips.mBtn.slot.position = tempSize
                Extension.UIManager.instance.showUI(tips, 5)
                // tips.uiObject.slot.zorder = this._guideUI.uiObject.slot.zorder + 4
                tips.mBtn.visibility = _guideUICfg.IsShowTip ? UI.SlateVisibility.Visible : UI.SlateVisibility.Collapsed
                this._tipsMap.set(_guideUICfg.ID, tips);
            }
        });
    }

    removeTips(ID: number, eventNum: number) {
        GameConfig.GuideUI.getAllElement().forEach(_guideUICfg => {
            if (_guideUICfg.EndEvent[0] == ID && _guideUICfg.EndEvent[1] == eventNum && this._tipsMap.has(_guideUICfg.ID)) {
                let tips = this._tipsMap.get(_guideUICfg.ID)
                Extension.UIManager.instance.hideUI(tips)
                this._tipsPool.push(tips)
                this._tipsMap.delete(_guideUICfg.ID);
            }
        });
    }

    creatTips() {
        let tips: GuideTipsUI_Generate = null
        if (this._tipsPool.length == 0) {
            tips = Extension.UIManager.instance.create(GuideTipsUI_Generate)
            tips.mBtn.onClicked.add(() => {
                Util.uploadMGS("ts_tutorial_step", "玩家点击第一个下一步时", { tutorial_step: 2 });
                this._guideUI.mBtn.onClicked.broadcast()
            });
        } else {
            tips = this._tipsPool.shift();
        }
        return tips;
    }
}
export default GuideModule_Client