/**
 * @Author       : 田可成
 * @Date         : 2022-10-31 10:11:50
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-10-31 10:12:11
 * @FilePath     : \ilovethemountains\JavaScripts\modules\commonModules\gm\GMManager.ts
 * @Description  : 
 */
import { AddGMCommand } from "module_gm";
import { ModuleManager, Singleton } from "odin";
import { ClientEvents } from "../../../const/LocalEvents";
import { UIGM } from "../../../ui/UIGM";
import { EventManager_C } from "../../playModule/event/EventManager_C";
import { PlayModule_Client } from "../../playModule/PlayModule_Client";
import { BagModule_Clinet } from "../bagModule/BagModule_Clinet";

@Singleton()
export class GMManager {
    static instance: GMManager
    isShow: boolean = false

    show() {
        if (this.isShow) {
            AddGMCommand("增加道具", (player: Gameplay.Player, value: string) => {
                ModuleManager.instance.getModule(BagModule_Clinet).addItemByCfg(Number(value))
            });
            AddGMCommand("触发事件", (player: Gameplay.Player, value: string) => {
                EventManager_C.instance.executeEvent(Number(value), "1", 1)
            });
            AddGMCommand("控制体力", (player: Gameplay.Player, value: string) => {
                ModuleManager.instance.getModule(PlayModule_Client).climber.property.stamina += Number(value);
                ModuleManager.instance.getModule(PlayModule_Client).refreshUI();
            });
            AddGMCommand("控制血量", (player: Gameplay.Player, value: string) => {
                ModuleManager.instance.getModule(PlayModule_Client).climber.property.hp += Number(value);
                ModuleManager.instance.getModule(PlayModule_Client).refreshUI();
            });
            AddGMCommand("重生到营地", (player: Gameplay.Player, value: string) => {
                Events.dispatchLocal(ClientEvents.Ev_ReturnCamp)
            });
            AddGMCommand("重生到篝火处", (player: Gameplay.Player, value: string) => {
                Events.dispatchLocal(ClientEvents.Ev_ReturnBornPoint)
            });
            AddGMCommand("重置游戏", (player: Gameplay.Player, value: string) => {
                Events.dispatchLocal(ClientEvents.EV_ResetGame)
            });
            
            new UIGM().show()
            let ui = new UIGM()
            ui.show()
        }
    }
}