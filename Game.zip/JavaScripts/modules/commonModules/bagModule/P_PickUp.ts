﻿/**
 * @Author       : 田可成
 * @Date         : 2022-10-12 09:17:17
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-12-26 14:02:27
 * @FilePath     : \ilovethemountains\JavaScripts\modules\commonModules\bagModule\P_PickUp.ts
 * @Description  : 
 */

import { ModuleManager } from "odin";
import { globalLanguage, LanguageIndex } from "../../../const/GlobleLanguage";
import PickUp_Generate from "../../../ui-generate/bagModule/PickUp_generate";
import P_Tips from "../../../ui/P_Tips";
import { Util } from "../../../util/Util";
import { GameModule_Client } from "../../gameModule/GameModule_Client";
import { BagModule_Clinet } from "./BagModule_Clinet";

export default class P_PickUp extends PickUp_Generate {
	protected onShow(...param: any): void {
		let params = param[0]
		this.mPickup.onClicked.clear();
		let itemID = params[0];
		let destroyGuid = params[1]
		let gold = params[2]
		let flagPos = params[3]
		let flagRot = params[4]
		let flagSca = params[5]
		if (itemID == 7) {
			this.mPickup.text = globalLanguage.getLanguage(LanguageIndex.插上旗子)
			this.mPickup.onClicked.add(() => {
				Util.playSound(16)
				//TODO:插旗子
				let str = Util.formatString(globalLanguage.getLanguage(LanguageIndex["增加{0}金币"]), gold)
				P_Tips.show(str);
				ModuleManager.instance.getModule(GameModule_Client).addGold(gold);
				ModuleManager.instance.getModule(GameModule_Client).plugFlag(flagPos, flagRot, flagSca)
				ModuleManager.instance.getModule(BagModule_Clinet).deleteItemByCfg(7);
			})
		} else {
			this.mPickup.text = globalLanguage.getLanguage(LanguageIndex.拾取)
			this.mPickup.onClicked.add(() => {
				Util.playSound(16)
				ModuleManager.instance.getModule(BagModule_Clinet).addItemByCfg(itemID);
				Util.uploadMGS("ts_action_click", "玩家点击拾取按钮", { button: "item" });
			})
		}
		this.mPickup.onClicked.add(() => {
			if (destroyGuid) {
				Core.GameObject.asyncFind(destroyGuid).then((obj) => {
					obj.setVisibility(Type.PropertyStatus.Off);
				})
			}
			this.visible = false
		})
	}
}
