import { BagModuleBaseS } from "module_bag";
import { BagData } from "./BagData";

/**
 * @Author       : 田可成
 * @Date         : 2022-08-19 11:47:09
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-10-30 16:52:56
 * @FilePath     : \ilovethemountains\JavaScripts\modules\commonModules\bagModule\BagModule_Server.ts
 * @Description  : 
 */
export class BagModule_Server extends BagModuleBaseS<BagData>{
    net_ReqSetItemCnt(id: string, num: number, player?: Gameplay.Player): boolean {
        let data = this.getPlayerData(player);
        let item = data.getItemByItemId(id)
        if (item) {
            item.count = num;
            data.saveData(false);
            this.ntfItemChange(player, item);
            return true
        }

        return false;
    }
    
    net_ReqAddItem(id: number, cfgId: number, num: number, player?: Gameplay.Player): boolean {
        let item = new BagData();
        item.id = id.toString();
        item.cfgId = cfgId;
        item.count = num;
        this.addItemToBag(player, [item]);
        return true;
    }
}