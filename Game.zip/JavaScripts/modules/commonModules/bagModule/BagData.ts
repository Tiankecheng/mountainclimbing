import { BagItemBase, BagModuleDataBase } from "module_bag";

/**
 * @Author       : 田可成
 * @Date         : 2022-08-19 11:45:53
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-10-30 16:45:12
 * @FilePath     : \ilovethemountains\JavaScripts\modules\commonModules\bagModule\BagData.ts
 * @Description  : 
 */
export class BagData extends BagItemBase {

}

export class BagDataHelper extends BagModuleDataBase<BagData>{
    
}