/**
 * @Author       : 田可成
 * @Date         : 2022-12-27 10:08:32
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-12-27 16:21:58
 * @FilePath     : \ilovethemountains\JavaScripts\modules\IAAModule\IAAData.ts
 * @Description  : 
 */
import { DataInfo, ModuleData, OldAPI_Action1 } from "odin";
import { GlobalVas } from "../../const/GlobalDefine";

class ADLimit {
    pos: IAAPos;
    count: number;
}

class IAADataInfo implements DataInfo {
    version: number
    /**
    * 所有限制次数
    */
    public limits: ADLimit[] = [
        { pos: IAAPos.Fly, count: GlobalVas.FlyAdsCount },
        { pos: IAAPos.Item, count: GlobalVas.MedicalAdsCount },
    ];
    /**
     * 上一次更新日期
     */
    public lastRefreshDay: number = 0;
}

export default class IAAData extends ModuleData<IAADataInfo> {
    public readonly ScoreAddDataChange: OldAPI_Action1<number> = new OldAPI_Action1()

    public constructor() {
        super(IAADataInfo)
    }

    protected initDefaultData(): void {
        this.dataInfo.limits = [];
        this.dataInfo.limits.push({ pos: IAAPos.Fly, count: GlobalVas.FlyAdsCount });
        this.dataInfo.limits.push({ pos: IAAPos.Item, count: GlobalVas.MedicalAdsCount });
        this.dataInfo.lastRefreshDay = new Date().getDate();
    }

    /**
    * 重置广告次数，需要判断时间
    */
    public resetDate() {
        const date = new Date().getDate();
        if (this.dataInfo.lastRefreshDay != date) {
            this.dataInfo.lastRefreshDay = date;
            this.dataInfo.limits.forEach(limit => {
                switch (limit.pos) {
                    case IAAPos.Fly:
                        limit.count = GlobalVas.FlyAdsCount;
                        break;
                    case IAAPos.Item:
                        limit.count = GlobalVas.MedicalAdsCount
                    default:
                        break;
                }
            });
            this.saveData(true);
        }
    }

    /**
     * 有多少次数
     * @param pos 
     * @returns 
     */
    public hasCount(pos: IAAPos): number {
        return this.dataInfo.limits.find(i => i.pos == pos).count;
    }
    /**
     * 减少次数
     * @param pos 
     */
    public reduceCount(pos: IAAPos) {
        const limit = this.dataInfo.limits.find(i => i.pos == pos);
        if (limit) {
            limit.count--;
        }
    }
}

export enum IAAPos {
    Fly,
    Item,
}