/**
 * @Author       : 田可成
 * @Date         : 2022-12-27 10:08:32
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-12-27 16:54:01
 * @FilePath     : \ilovethemountains\JavaScripts\modules\IAAModule\IAAModuleC.ts
 * @Description  : 
 */
import { ModuleC, ModuleManager } from "odin";
import { GlobalVas } from "../../const/GlobalDefine";
import { ClientEvents } from "../../const/LocalEvents";
import { BagModule_Clinet } from "../commonModules/bagModule/BagModule_Clinet";
import P_LobbyUI from "../gameModule/P_LobbyUI";
import { PlayModule_Client } from "../playModule/PlayModule_Client";
import { AdvUI } from "./AdvUI";
import IAAData, { IAAPos } from "./IAAData";
import { IAAModuleS } from "./IAAModuleS";

export class IAAModuleC extends ModuleC<IAAModuleS, IAAData>{
    /**广告经过时间 */
    private _adsTime: number = 0;
    /**关卡死亡次数 */
    private _actorDeathCount: number = 0

    onStart(): void {
        Extension.UIManager.instance.getUI(P_LobbyUI).mAdv.visibility = UI.SlateVisibility.Visible
        Extension.UIManager.instance.getUI(P_LobbyUI).mAdv.onClicked.add(() => {
            Extension.UIManager.instance.show(AdvUI, IAAPos.Item)
        })

        Events.addLocalListener(ClientEvents.EV_RefreshSavePoint, () => {
            this._actorDeathCount = 0
        })

        Events.addLocalListener(ClientEvents.Ev_DeathToBornPoint, () => {
            this._actorDeathCount++
            console.log(this._actorDeathCount)
            if (this._actorDeathCount >= GlobalVas.FlyAdsDeathCount) {
                this._actorDeathCount = 0
                Extension.UIManager.instance.show(AdvUI, IAAPos.Fly)
            }
        })

        Events.addLocalListener(ClientEvents.EV_EnterGuide, () => {
            Extension.UIManager.instance.getUI(P_LobbyUI).mAdv.visibility = UI.SlateVisibility.Collapsed
        })

        Events.addLocalListener(ClientEvents.EV_ExitGuide, () => {
            Extension.UIManager.instance.getUI(P_LobbyUI).mAdv.visibility = UI.SlateVisibility.Visible
        })
        this.resetData()
    }

    /**
    * 播放激励广告
    * @param pos 
    */
    public net_ShowRewardAd(pos: IAAPos, ownData?: { [key: string]: number | string }) {
        if (!Service.AdsService.getInstance().isActive(Service.AdsType.Reward)) return
        if (this.data.hasCount(pos) > 0) {
            Service.AdsService.getInstance().isReady(Service.AdsType.Reward, isReady => {
                if (isReady) {
                    Service.AdsService.getInstance().show(Service.AdsType.Reward, state => {
                        if (state == Service.AdsState.Reward) {
                            console.log("广告播放成功！！！")
                            Extension.UIManager.instance.getUI(P_LobbyUI).mAdTips.text = "广告播放成功！！！"
                            this.onRewardAdSuccess(pos, ownData);
                        } else if (state == Service.AdsState.Fail || state == Service.AdsState.Close) {
                            console.log("播放广告失败")
                            // TipsUI.show(globalLanguage.getLanguage(LanguageIndex.广告播放失败));
                            Extension.UIManager.instance.getUI(P_LobbyUI).mAdTips.text = "播放广告失败"
                        }
                    });
                } else {
                    console.log("广告还没准备好")
                    Extension.UIManager.instance.getUI(P_LobbyUI).mAdTips.text = "广告还没准备好"
                }
            });
        } else {
            console.log("次数不足")
            // TipsUI.show(globalLanguage.getLanguage(LanguageIndex.已达到今日上限));
            Extension.UIManager.instance.getUI(P_LobbyUI).mAdTips.text = "次数不足"
        }
    }

    /**
     * @description: 播放插入广告
     * @return {*}
     */
    public net_ShowInterstitialAd() {
        if (!Service.AdsService.getInstance().isActive(Service.AdsType.Interstitial)) return
        Service.AdsService.getInstance().isReady(Service.AdsType.Interstitial, isReady => {
            if (isReady) {
                Service.AdsService.getInstance().show(Service.AdsType.Interstitial, isSuccess => {
                    if (isSuccess == Service.AdsState.Fail) {
                        GlobalVas.g_AdsIsStart = true
                        this._adsTime = 0
                        Extension.UIManager.instance.getUI(P_LobbyUI).mAdTips.text = "播放广告失败"
                    } else if (isSuccess == Service.AdsState.Close) {
                        GlobalVas.g_AdsIsStart = true
                        this._adsTime = 0
                        Extension.UIManager.instance.getUI(P_LobbyUI).mAdTips.text = "玩家关闭了"
                    }
                });
            } else {
                GlobalVas.g_AdsIsStart = true
                this._adsTime = 0
                Extension.UIManager.instance.getUI(P_LobbyUI).mAdTips.text = "未准备好"
            }
        });
    }

    private onRewardAdSuccess = (pos: IAAPos, ownData?: { [key: string]: number | string }) => {
        this.server.net_onPlaySuccess(pos, ownData);
        switch (pos) {
            case IAAPos.Fly:
                this.currentPlayer.character.switchToFlying()
                setTimeout(() => {
                    this.currentPlayer.character.switchToWalking()
                }, GlobalVas.FlyTime * 1000);
                break;
            case IAAPos.Item:
                ModuleManager.instance.getModule(BagModule_Clinet).addItemByCfg(0)
                break;
        }
    }

    private resetData() {
        this.server.net_resetDate();
    }

    onUpdate(dt: number): void {
        if (!GlobalVas.g_AdsIsStart) return
        if (dt >= 0.03) return;
        this._adsTime += dt;
        let countDown = this._adsTime + ModuleManager.instance.getModule(PlayModule_Client).climber.savePointID * GlobalVas.AdsLevelTime
        Extension.UIManager.instance.getUI(P_LobbyUI).mAdCountDown.text = "广告倒计时：" + (GlobalVas.AdsTime - countDown).toFixed(0)
        if (countDown > GlobalVas.AdsTime) {
            GlobalVas.g_AdsIsStart = false
            this.net_ShowInterstitialAd()
        }
    }
}