import { GameConfig } from "../../../config/GameConfig";
import { Util } from "../../../util/Util";
import { BaseActor } from "./BaseActor";
import Property from "./Property";

export class Climber extends BaseActor {
    /**控制的玩家对象 */
    get player(): Gameplay.Player {
        return Gameplay.getPlayer(this.pid)
    }
    /**玩家对象角色控制器 */
    protected _character: Gameplay.Character
    public get character() {
        return this._character;
    }

    /**属性 */
    property: Property
    /**经过的存档点 */
    savePointID: number = 1
    /**死亡次数 */
    deathCount: number = 0;
    /**复活次数 */
    rebirthCount: number = 0;
    /**计时器 */
    timer: number = 0;

    constructor(player: Gameplay.Player) {
        super();
        if (player) {
            this._character = player.character;
            this._guid = this.character.guid
            this._pid = player.getPlayerID();
            this.isAI = false;
        }
        this.property = new Property()
    }

    /**
     * @description: 进行一些必要初始化
     * @return {*}
     */
    init() {
        super.init();
        this._dead = false;
        this.savePointID = 1;
        this.property.reset()
        this.timer = Date.now()
    }

    /**销毁 */
    destroy() {
        super.destroy();
        this.property.reset()
    }

    onDead(): void {
        super.onDead()
        this.character.enableRagdoll = true
        this.character.enableMove = false;

        this.deathCount++;
        Util.uploadMGS("ts_action_dead", "玩家生命值到0死亡时", { death: this.deathCount });
    }

    onPlay() {
        super.onPlay()
        this.character.enableRagdoll = false
        this.character.enableMove = true;
        this.property.hp = GameConfig.PlayerConfig.getElement(1).MaxHP
        this.property.stamina = GameConfig.PlayerConfig.getElement(1).MaxStamina
    }

    onFall() {
        super.onDead()
        this.character.enableRagdoll = true
        this.character.enableMove = false;
    }

    onReturn() {
        super.onPlay()
        this.character.enableRagdoll = false
        this.character.enableMove = true;
    }
}