/**
 * @Author       : 田可成
 * @Date         : 2022-08-18 10:12:29
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-11-11 15:39:55
 * @FilePath     : \ilovethemountains\JavaScripts\modules\playModule\PlayModule_Server.ts
 * @Description  : 
 */
import { ModuleS } from "odin";
import ScoreMgr from "../../../Prefabs/PlayerScore/Script/ScoreMgr";
import { PlayDataHelper } from "./PlayData";
import { PlayModule_Client } from "./PlayModule_Client";


export class PlayModule_Server extends ModuleS<PlayModule_Client, PlayDataHelper>{
    net_PlayerReborn(bornPoint: Type.Vector, player?: Gameplay.Player) {
        player.character.worldLocation = bornPoint
    }

    net_RefreshSavePoint(savePoint: number, player?: Gameplay.Player) {
        ScoreMgr.instance.refreshSavePoint(player.getPlayerID(), savePoint);
    }

    net_AddTopCount(player?: Gameplay.Player) {
        let result = this.currentData.addTopCount()
        this.currentData.saveData(true)
        ScoreMgr.instance.refreshTopCount(player.getPlayerID(), result);
    }
}

