/**
 * @Author       : 田可成
 * @Date         : 2022-08-16 10:33:43
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-11-11 15:40:13
 * @FilePath     : \ilovethemountains\JavaScripts\modules\playModule\PlayData.ts
 * @Description  : 
 */

import { DataInfo, ModuleData } from "odin";
export class PlayData extends DataInfo {
    topCount: number = 0
}

export class PlayDataHelper extends ModuleData<PlayData>{

    public constructor() {
        super(PlayData);
    }

    public addTopCount() {
        this.dataInfo.topCount++
        return this.dataInfo.topCount;
    }

    public getTopCount(): number {
        return this.dataInfo.topCount
    }
}