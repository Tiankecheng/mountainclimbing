import { Singleton } from "odin";
import { GameConfig } from "../../../config/GameConfig";
import P_EventUI from "./P_EventUI";

/**
 * @Author       : 田可成
 * @Date         : 2022-08-18 14:14:23
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-10-31 10:06:05
 * @FilePath     : \ilovethemountains\JavaScripts\modules\playModule\event\EventManager_C.ts
 * @Description  : 
 */
@Singleton()
export class EventManager_C {
    public static instance: EventManager_C;
    destroyObj: Core.GameObject[] = [];
    eventBuff: number[] = [];

    executeEvent(eventID: number, eventTypes: string, count: number, destroyGuid?: string) {
        let events: number[] = [];
        eventTypes.split(",").forEach(eventType => {
            GameConfig.Event.getAllElement().forEach(cfg => {
                if (cfg.EventType == Number(eventType) && this.eventBuff.indexOf(cfg.id) == -1) {
                    events.push(cfg.ID)
                }
            });
        });
        let res: number[] = [];
        if (eventID == 0) {
            for (let i = 0; i < count; i++) {
                res.push(this.getRandomEvent(events))
            }
        } else {
            res.push(eventID);
        }
        Extension.UIManager.instance.show(P_EventUI, res)
        if (destroyGuid) {
            Core.GameObject.asyncFind(destroyGuid).then((obj) => {
                obj.setVisibility(Type.PropertyStatus.Off);
                this.destroyObj.push(obj);
            })
        }
    }

    /**从数组里获取1个随机的事件 */
    getRandomEvent(events: number[]): number {
        let sum = 0;
        let res = 0;
        for (let i = 0; i < events.length; i++) {
            sum += GameConfig.Event.getElement(events[i]).Weight;
        }

        let random = Math.random() * sum;
        let num = 0;
        for (let i = 0; i < events.length; i++) {
            num += GameConfig.Event.getElement(events[i]).Weight;
            if (num >= random) {
                res = events[i]
                events.splice(events.indexOf(res), 1)
                break;
            }
        }
        return res
    }

    resetEventObj() {
        this.destroyObj.forEach((obj) => {
            obj.setVisibility(Type.PropertyStatus.On);
        })
        this.eventBuff.length = 0;
        this.destroyObj.length = 0;
    }
}