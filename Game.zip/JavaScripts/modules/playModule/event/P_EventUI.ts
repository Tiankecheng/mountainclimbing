import { DataCenterC, ModuleManager } from "odin";
import { GameConfig } from "../../../config/GameConfig";
import { GlobalVas } from "../../../const/GlobalDefine";
import EventItem_Generate from "../../../ui-generate/eventModule/EventItem_generate";
import EventUI_Generate from "../../../ui-generate/eventModule/EventUI_generate";
import { Util } from "../../../util/Util";
import GuideModule_Client from "../../commonModules/guide/GuideModule_Client";
import { GameDataHelper } from "../../gameModule/GameData";
import P_LobbyUI from "../../gameModule/P_LobbyUI";
import P_EventDecUI from "./P_EventDecUI";


/**
 * @Author       : 田可成
 * @Date         : 2022-08-23 17:37:56
 * @LastEditors  : 田可成
 * @LastEditTime : 2022-09-23 18:42:27
 * @FilePath     : \JavaScripts\playModule\event\P_EventUI.ts
 * @Description  : 
 */
export default class P_EventUI extends EventUI_Generate {

    private eventItemArr: EventItem_Generate[] = []
    onStart(): void {
        DataCenterC.instance.getModuleData(GameDataHelper).OnGoldNumChange.add((goldnum: number) => this.mGoldCnt.text = goldnum.toString())
        for (let i = 0; i < 3; i++) {
            let item: EventItem_Generate = Extension.UIManager.instance.create(EventItem_Generate)
            this.mEventCanvas.addChild(item.uiObject)
            item.uiObject.slot.size = itemSize
            item.uiObject.visibility = UI.SlateVisibility.Collapsed
            this.eventItemArr.push(item)
        }
    }

    protected onShow(...params: any[]): void {
        this.mGoldCnt.text = DataCenterC.instance.getModuleData(GameDataHelper).GetGoldNum().toString()
        Util.playSound(15)
        let events: number[] = params[0];
        for (let i = 0; i < events.length; i++) {
            this.eventItemArr[i].mDesc.text = GameConfig.Event.getElement(events[i]).Dec
            this.eventItemArr[i].mEventName.text = GameConfig.Event.getElement(events[i]).Name
            this.eventItemArr[i].mBtn.onClicked.clear();
            this.eventItemArr[i].mBtn.onClicked.add(() => {
                Util.playSound(16)
                GlobalVas.g_GameIsGuide ? ModuleManager.instance.getModule(GuideModule_Client).triggerGuide(7) : null;
                Util.uploadMGS("ts_action_click", "玩家点击事件选择按钮", { button: "event" });
                Extension.UIManager.instance.hide(P_EventUI)
                Extension.UIManager.instance.show(P_EventDecUI, events[i])
            })
            this.eventItemArr[i].uiObject.visibility = UI.SlateVisibility.Visible
        }
        Extension.UIManager.instance.hide(P_LobbyUI)
        Gameplay.getCurrentPlayer().character.enableMove = false
    }

    protected onHide(): void {
        for (let i = 0; i < this.eventItemArr.length; i++) {
            this.eventItemArr[i].uiObject.visibility = UI.SlateVisibility.Collapsed
        }
    }
}
const itemSize: Type.Vector2 = new Type.Vector2(420, 526)